<?php
$value = 14;
$result = DoubleUp($value);
print "Calling DoubleUp($value) returned $result";
?>