
$Header: /Users/dossy/Desktop/cvs/aolserver/tests/README-tests.txt,v 1.1 2000/10/09 20:29:54 kriston Exp $


Confidence Tests
----------------

Install these pages into your server's pageroot to perform some simple
confidence tests.

