var PHP_ZTS ="yes"
var PHP_DLL_LIB ="php5ts.lib"
var PHP_DLL ="php5ts.dll"
var PHP_ANALYZER ="no"
var PHP_PGO ="no"
var PHP_PGI ="no"
var PHP_ALL_SHARED ="no"

